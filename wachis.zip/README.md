# Wachis (Forge 1.20.1)

Los Wachis son seres adorables y torpes que vagan por el mundo buscando tesoros.

## Qué añade
- **Wachi** (4 colores): tímido, anda como un patito, cava hoyos buscando cosas y a veces tropieza y se cae de bruces.
- **Campamento Wachi**: tienda, hoguera, cofre con provisiones y un **mapa del tesoro**, con 3 Wachis viviendo allí.
- **Tesoro enterrado**: una cámara de piedra a 1-2 bloques bajo la superficie, con un cofre de botín (esmeraldas, oro,
  diamantes, libros encantados, objetos raros y, a veces, otro mapa a un tesoro nuevo). Hay uno cada ~200 bloques.
- **Moneda Wachi** (botín) y **Huevo generador de Wachi** (pestaña creativa "Wachis").

## Cómo se juega
- **Hacerte amigo**: sostén oro (pepita), esmeralda o Moneda Wachi y haz clic derecho (1 de cada 3 veces funciona).
  Si te agachas o llevas una golosina, no huyen de ti.
- **Wachi amigo**:
  - Te sigue. Clic derecho con la mano vacía: se sienta / te sigue.
  - **Mapa**: clic derecho con un **mapa vacío** -> te dibuja un mapa del tesoro (cooldown 5 min).
  - **Guía**: **agáchate + clic derecho con la mano vacía** -> te lleva al tesoro enterrado más cercano.
    Camina delante de ti (te espera si te quedas atrás), cava al llegar y deja una **columna de luz 60 s**.
    Cava ahí y encontrarás la cámara.
  - Golosina = cura al Wachi.
- Los Wachis (salvajes o amigos) cavan hoyos y a veces sacan huesos, pepitas, monedas... o nada.

## Compilar en GitHub
1. Sube TODO el contenido de esta carpeta (incluida `.github`) a la raíz del repositorio.
2. Actions -> "Build Wachis" -> al terminar, Artifacts -> `wachis-jar`.

## Ajustes
- Frecuencia de estructuras: `data/wachis/worldgen/structure_set/*.json` (`spacing`/`separation`).
- Botín: `data/wachis/loot_tables/`.
- Aparición de Wachis: `data/wachis/forge/biome_modifier/wachi_spawns.json`.
- Comportamiento: `entity/WachiEntity.java` y `entity/ai/`.
