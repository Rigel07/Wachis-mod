package com.wachis.util;

import com.wachis.WachisMod;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.MapItem;
import net.minecraft.world.level.saveddata.maps.MapDecoration;
import net.minecraft.world.level.saveddata.maps.MapItemSavedData;
import net.minecraft.world.level.levelgen.structure.Structure;
import org.jetbrains.annotations.Nullable;

public class TreasureFinder {
    /** Etiqueta de estructuras con tesoro (data/wachis/tags/worldgen/structure/treasure_spot.json). */
    public static final TagKey<Structure> TREASURE_SPOT =
            TagKey.create(Registries.STRUCTURE, new ResourceLocation(WachisMod.MOD_ID, "treasure_spot"));

    /** Tesoro mas cercano. radius en chunks. skipKnown=true busca tesoros aun sin explorar. */
    @Nullable
    public static BlockPos find(ServerLevel level, BlockPos from, int radiusChunks, boolean skipKnown) {
        return level.findNearestMapStructure(TREASURE_SPOT, from, radiusChunks, skipKnown);
    }

    /** Mapa del tesoro con una X roja (igual que los mapas de exploracion vanilla). */
    public static ItemStack createMap(ServerLevel level, BlockPos target) {
        ItemStack map = MapItem.create(level, target.getX(), target.getZ(), (byte) 2, true, true);
        MapItem.renderBiomePreviewMap(level, map);
        MapItemSavedData.addTargetDecoration(map, target, "+", MapDecoration.Type.RED_X);
        map.setHoverName(Component.translatable("item.wachis.wachi_map"));
        return map;
    }
}
