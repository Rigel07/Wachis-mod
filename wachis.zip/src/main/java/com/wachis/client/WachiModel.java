package com.wachis.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.wachis.WachisMod;
import com.wachis.entity.WachiEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Wachi: cabezon redondo, cuerpecito, sombrero de explorador, mochila y un mapa en la mano. */
public class WachiModel extends EntityModel<WachiEntity> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(WachisMod.MOD_ID, "wachi"), "main");

    private final ModelPart root, head, body, leftArm, rightArm, leftLeg, rightLeg;

    public WachiModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.body = root.getChild("body");
        this.leftArm = root.getChild("left_arm");
        this.rightArm = root.getChild("right_arm");
        this.leftLeg = root.getChild("left_leg");
        this.rightLeg = root.getChild("right_leg");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition pd = mesh.getRoot();

        PartDefinition head = pd.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 0).addBox(-5F, -9F, -4.5F, 10F, 9F, 9F),
                PartPose.offset(0F, 14F, 0F));
        head.addOrReplaceChild("hat_brim",
                CubeListBuilder.create().texOffs(0, 18).addBox(-6F, -10F, -6F, 12F, 1F, 12F), PartPose.ZERO);
        head.addOrReplaceChild("hat_crown",
                CubeListBuilder.create().texOffs(0, 31).addBox(-3.5F, -13F, -3.5F, 7F, 3F, 7F), PartPose.ZERO);

        PartDefinition body = pd.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(0, 41).addBox(-4F, -7F, -3F, 8F, 7F, 6F),
                PartPose.offset(0F, 20F, 0F));
        body.addOrReplaceChild("backpack",
                CubeListBuilder.create().texOffs(30, 41).addBox(-3F, -6.5F, 3F, 6F, 6F, 3F), PartPose.ZERO);

        pd.addOrReplaceChild("left_arm",
                CubeListBuilder.create().texOffs(50, 18).addBox(-1F, 0F, -1F, 2F, 5F, 2F),
                PartPose.offset(5F, 14.5F, 0F));
        PartDefinition rightArm = pd.addOrReplaceChild("right_arm",
                CubeListBuilder.create().texOffs(50, 26).addBox(-1F, 0F, -1F, 2F, 5F, 2F),
                PartPose.offset(-5F, 14.5F, 0F));
        rightArm.addOrReplaceChild("map",
                CubeListBuilder.create().texOffs(0, 56).addBox(-2.5F, 4F, -6F, 5F, 1F, 5F), PartPose.ZERO);

        pd.addOrReplaceChild("left_leg",
                CubeListBuilder.create().texOffs(30, 31).addBox(-1.5F, 0F, -1.5F, 3F, 4F, 3F),
                PartPose.offset(2F, 20F, 0F));
        pd.addOrReplaceChild("right_leg",
                CubeListBuilder.create().texOffs(44, 34).addBox(-1.5F, 0F, -1.5F, 3F, 4F, 3F),
                PartPose.offset(-2F, 20F, 0F));

        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(WachiEntity e, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        boolean sitting = e.isInSittingPose();
        this.root.y = sitting ? 3.0F : 0.0F;

        this.head.yRot = netHeadYaw * Mth.DEG_TO_RAD;
        this.head.xRot = headPitch * Mth.DEG_TO_RAD;
        this.head.zRot = 0F;
        this.body.zRot = 0F;

        float swing = limbSwing * 0.8F;
        if (sitting) {
            this.leftLeg.xRot = -1.4F;
            this.rightLeg.xRot = -1.4F;
            this.leftArm.xRot = 0F;
        } else {
            this.rightLeg.xRot = Mth.cos(swing) * 1.3F * limbSwingAmount;
            this.leftLeg.xRot = Mth.cos(swing + Mth.PI) * 1.3F * limbSwingAmount;
            this.leftArm.xRot = Mth.cos(swing) * 0.9F * limbSwingAmount;
            // andar de patito (torpe)
            this.body.zRot = Mth.sin(swing) * 0.12F * limbSwingAmount;
            this.head.zRot = -this.body.zRot * 0.6F;
        }
        this.leftArm.zRot = 0.08F + Mth.sin(ageInTicks * 0.09F) * 0.04F;
        // sostiene el mapa delante
        this.rightArm.xRot = -0.9F + Mth.sin(ageInTicks * 0.1F) * 0.05F;

        if (e.isDigging()) {
            this.head.xRot = 0.9F + Mth.sin(ageInTicks * 1.3F) * 0.15F;
            this.leftArm.xRot = -1.3F + Mth.sin(ageInTicks * 1.6F) * 0.7F;
            this.rightArm.xRot = -1.3F + Mth.sin(ageInTicks * 1.6F + Mth.PI) * 0.7F;
        }
        if (e.isTripped()) {
            this.leftArm.xRot = -2.6F + Mth.sin(ageInTicks * 0.8F) * 0.2F;
            this.rightArm.xRot = -2.6F + Mth.sin(ageInTicks * 0.8F + 1F) * 0.2F;
            this.leftLeg.xRot = 0.3F;
            this.rightLeg.xRot = -0.3F;
        }
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float r, float g, float b, float a) {
        this.root.render(poseStack, buffer, packedLight, packedOverlay, r, g, b, a);
    }
}
