package com.wachis.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.wachis.WachisMod;
import com.wachis.entity.WachiEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class WachiRenderer extends MobRenderer<WachiEntity, WachiModel> {
    private static final ResourceLocation[] TEXTURES = new ResourceLocation[WachiEntity.VARIANTS];

    static {
        for (int i = 0; i < TEXTURES.length; i++) {
            TEXTURES[i] = new ResourceLocation(WachisMod.MOD_ID, "textures/entity/wachi_" + i + ".png");
        }
    }

    public WachiRenderer(EntityRendererProvider.Context context) {
        super(context, new WachiModel(context.bakeLayer(WachiModel.LAYER)), 0.35F);
    }

    @Override
    public ResourceLocation getTextureLocation(WachiEntity entity) {
        return TEXTURES[entity.getVariant()];
    }

    @Override
    protected void scale(WachiEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(0.75F, 0.75F, 0.75F);
    }

    @Override
    protected void setupRotations(WachiEntity entity, PoseStack poseStack, float bob, float yBodyRot, float partialTick) {
        super.setupRotations(entity, poseStack, bob, yBodyRot, partialTick);
        float t = entity.getTripProgress(partialTick);
        if (t > 0F) {
            // se cae de bruces hacia delante
            poseStack.translate(0.0D, 0.1D * t, 0.0D);
            poseStack.mulPose(Axis.XP.rotationDegrees(-85.0F * t));
        }
    }
}
