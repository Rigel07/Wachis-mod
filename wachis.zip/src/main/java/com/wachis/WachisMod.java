package com.wachis;

import com.wachis.entity.ModEntities;
import com.wachis.item.ModCreativeTabs;
import com.wachis.item.ModItems;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(WachisMod.MOD_ID)
public class WachisMod {
    public static final String MOD_ID = "wachis";

    public WachisMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModEntities.ENTITIES.register(bus);
        ModItems.ITEMS.register(bus);
        ModCreativeTabs.TABS.register(bus);
    }
}
