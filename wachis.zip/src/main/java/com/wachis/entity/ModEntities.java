package com.wachis.entity;

import com.wachis.WachisMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, WachisMod.MOD_ID);

    public static final RegistryObject<EntityType<WachiEntity>> WACHI =
            ENTITIES.register("wachi", () ->
                    EntityType.Builder.<WachiEntity>of(WachiEntity::new, MobCategory.CREATURE)
                            .sized(0.6f, 1.1f)
                            .clientTrackingRange(10)
                            .build(new ResourceLocation(WachisMod.MOD_ID, "wachi").toString()));
}
