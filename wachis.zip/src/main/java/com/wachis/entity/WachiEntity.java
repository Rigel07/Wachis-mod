package com.wachis.entity;

import com.wachis.WachisMod;
import com.wachis.entity.ai.DigForTreasureGoal;
import com.wachis.entity.ai.GuideToTreasureGoal;
import com.wachis.item.ModItems;
import com.wachis.util.TreasureFinder;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.AvoidEntityGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.FollowOwnerGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.SitWhenOrderedToGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.parameters.LootContextParamSets;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import org.jetbrains.annotations.Nullable;

import java.util.function.Predicate;

/**
 * Wachi: criatura adorable y torpe que vaga por el mundo buscando tesoros.
 *  - Salvaje: tímido, cava buscando, tropieza de vez en cuando.
 *  - Amigo (le das oro/esmeralda/moneda): te sigue, te dibuja mapas (con un mapa vacio)
 *    y te guia hasta el tesoro enterrado mas cercano (clic derecho con la mano vacia + agachado).
 */
public class WachiEntity extends TamableAnimal {
    public static final int VARIANTS = 4;
    public static final int TRIP_DURATION = 50;

    private static final EntityDataAccessor<Integer> VARIANT =
            SynchedEntityData.defineId(WachiEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> TRIPPED =
            SynchedEntityData.defineId(WachiEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> DIGGING =
            SynchedEntityData.defineId(WachiEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> GUIDING =
            SynchedEntityData.defineId(WachiEntity.class, EntityDataSerializers.BOOLEAN);

    private int tripTimer = 0;
    private int animTick = 0; // solo cliente
    private int mapCooldown = 0;
    @Nullable
    private BlockPos treasureTarget;
    @Nullable
    private BlockPos markerPos;
    private int markerTicks = 0;

    public WachiEntity(EntityType<? extends WachiEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return TamableAnimal.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 12.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D)
                .add(Attributes.FOLLOW_RANGE, 16.0D);
    }

    public static boolean checkWachiSpawnRules(EntityType<WachiEntity> type, LevelAccessor level,
                                               MobSpawnType reason, BlockPos pos, RandomSource random) {
        BlockState below = level.getBlockState(pos.below());
        boolean ground = below.is(BlockTags.ANIMALS_SPAWNABLE_ON) || below.is(BlockTags.SAND)
                || below.is(BlockTags.DIRT) || below.is(BlockTags.TERRACOTTA);
        return ground && level.getRawBrightness(pos, 0) > 8;
    }

    // ------------------------------------------------------------ IA
    @Override
    protected void registerGoals() {
        // Los salvajes huyen de ti, salvo que te agaches o lleves una golosina en la mano
        Predicate<LivingEntity> shy = e -> !this.isTame() && e instanceof Player p
                && !(p.isCrouching() || isTreat(p.getMainHandItem()) || isTreat(p.getOffhandItem()));

        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new PanicGoal(this, 1.6D));
        this.goalSelector.addGoal(2, new SitWhenOrderedToGoal(this));
        this.goalSelector.addGoal(3, new GuideToTreasureGoal(this));
        this.goalSelector.addGoal(4, new FollowOwnerGoal(this, 1.15D, 7.0F, 2.0F, false));
        this.goalSelector.addGoal(5, new AvoidEntityGoal<Player>(this, Player.class, shy, 7.0F, 1.0D, 1.35D, shy));
        this.goalSelector.addGoal(6, new DigForTreasureGoal(this));
        this.goalSelector.addGoal(7, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(9, new RandomLookAroundGoal(this));
    }

    // ------------------------------------------------------------ datos
    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(VARIANT, 0);
        this.entityData.define(TRIPPED, false);
        this.entityData.define(DIGGING, false);
        this.entityData.define(GUIDING, false);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Variant", getVariant());
        tag.putInt("MapCooldown", this.mapCooldown);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        setVariant(tag.getInt("Variant"));
        this.mapCooldown = tag.getInt("MapCooldown");
    }

    public int getVariant() { return Mth.clamp(this.entityData.get(VARIANT), 0, VARIANTS - 1); }
    public void setVariant(int v) { this.entityData.set(VARIANT, Mth.clamp(v, 0, VARIANTS - 1)); }
    public boolean isTripped() { return this.entityData.get(TRIPPED); }
    public void setTripped(boolean b) { this.entityData.set(TRIPPED, b); }
    public boolean isDigging() { return this.entityData.get(DIGGING); }
    public void setDigging(boolean b) { this.entityData.set(DIGGING, b); }
    public boolean isGuiding() { return this.entityData.get(GUIDING); }
    public void setGuiding(boolean b) { this.entityData.set(GUIDING, b); }
    @Nullable
    public BlockPos getTreasureTarget() { return this.treasureTarget; }

    /** 0..1 para la animacion de tropiezo (cliente). */
    public float getTripProgress(float partialTick) {
        if (!isTripped()) return 0f;
        float t = this.animTick + partialTick;
        return Mth.clamp(Math.min(t, TRIP_DURATION - t) / 6f, 0f, 1f);
    }

    @Nullable
    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                        MobSpawnType reason, @Nullable SpawnGroupData spawnData,
                                        @Nullable CompoundTag dataTag) {
        setVariant(level.getRandom().nextInt(VARIANTS));
        return super.finalizeSpawn(level, difficulty, reason, spawnData, dataTag);
    }

    @Override
    public boolean isBaby() { return false; }

    @Override
    public boolean isFood(ItemStack stack) { return false; }

    @Nullable
    @Override
    public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob other) { return null; }

    public static boolean isTreat(ItemStack stack) {
        return stack.is(Items.GOLD_NUGGET) || stack.is(Items.EMERALD) || stack.is(ModItems.WACHI_COIN.get());
    }

    // ------------------------------------------------------------ comportamiento
    @Override
    protected boolean isImmobile() {
        return super.isImmobile() || this.isTripped();
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide) {
            this.animTick = isTripped() ? this.animTick + 1 : 0;
            if (isGuiding() && this.tickCount % 20 == 0) {
                this.level().addParticle(ParticleTypes.NOTE, getX(), getY() + 1.4, getZ(), this.random.nextDouble(), 0, 0);
            }
            return;
        }

        if (this.tripTimer > 0) {
            this.tripTimer--;
            if (this.tripTimer == 0) setTripped(false);
        } else if (!isInSittingPose() && !isDigging() && this.onGround()) {
            double speedSqr = getDeltaMovement().horizontalDistanceSqr();
            int chance = this.getLastHurtByMob() != null ? 50 : 900; // con el susto tropiezan mas
            if (speedSqr > 0.002 && this.random.nextInt(chance) == 0) trip();
        }

        if (this.mapCooldown > 0) this.mapCooldown--;

        if (this.markerTicks > 0 && this.markerPos != null && this.level() instanceof ServerLevel sl) {
            this.markerTicks--;
            if (this.markerTicks % 3 == 0) {
                sl.sendParticles(ParticleTypes.END_ROD, markerPos.getX() + 0.5 + (random.nextDouble() - 0.5) * 0.6,
                        markerPos.getY() + random.nextDouble() * 12, markerPos.getZ() + 0.5 + (random.nextDouble() - 0.5) * 0.6,
                        1, 0, 0.05, 0, 0.0);
            }
        }
    }

    private void trip() {
        setTripped(true);
        this.tripTimer = TRIP_DURATION;
        getNavigation().stop();
        this.playSound(SoundEvents.PANDA_SNEEZE, 0.8F, 1.6F);
        if (this.level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.CLOUD, getX(), getY() + 0.1, getZ(), 6, 0.3, 0.05, 0.3, 0.02);
        }
    }

    // ------------------------------------------------------------ cavar
    public void digEffects() {
        if (!(this.level() instanceof ServerLevel sl)) return;
        BlockState state = sl.getBlockState(blockPosition().below());
        if (state.isAir()) return;
        sl.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, state),
                getX(), getY() + 0.1, getZ(), 8, 0.25, 0.05, 0.25, 0.05);
        this.playSound(state.getSoundType().getBreakSound(), 0.6F, 1.2F);
    }

    /** Fin de un hoyo "libre": a veces nada, a veces un pequeno hallazgo. */
    public void finishDig() {
        if (!(this.level() instanceof ServerLevel sl)) return;
        if (this.random.nextFloat() < 0.45F) {
            sl.sendParticles(ParticleTypes.SMOKE, getX(), getY() + 0.8, getZ(), 6, 0.2, 0.2, 0.2, 0.01);
            this.playSound(SoundEvents.VILLAGER_NO, 0.6F, 1.7F);
            return;
        }
        LootTable table = sl.getServer().getLootData().getLootTable(new ResourceLocation(WachisMod.MOD_ID, "gameplay/wachi_dig"));
        LootParams params = new LootParams.Builder(sl)
                .withParameter(LootContextParams.ORIGIN, position())
                .withParameter(LootContextParams.THIS_ENTITY, this)
                .create(LootContextParamSets.GIFT);
        for (ItemStack stack : table.getRandomItems(params)) {
            this.spawnAtLocation(stack);
        }
        sl.sendParticles(ParticleTypes.HAPPY_VILLAGER, getX(), getY() + 0.9, getZ(), 6, 0.3, 0.3, 0.3, 0.02);
        this.playSound(SoundEvents.ALLAY_ITEM_GIVEN, 0.8F, 1.4F);
    }

    // ------------------------------------------------------------ guiar al tesoro
    private void toggleGuiding(Player player) {
        if (isGuiding()) {
            stopGuiding(player, false);
            return;
        }
        if (!(this.level() instanceof ServerLevel sl)) return;
        BlockPos t = TreasureFinder.find(sl, blockPosition(), 64, false);
        if (t == null) {
            player.displayClientMessage(Component.translatable("message.wachis.no_treasure"), true);
            this.playSound(SoundEvents.VILLAGER_NO, 0.7F, 1.6F);
            return;
        }
        this.treasureTarget = t;
        setOrderedToSit(false);
        setGuiding(true);
        this.playSound(SoundEvents.ALLAY_AMBIENT_WITH_ITEM, 1.0F, 1.3F);
        player.displayClientMessage(Component.translatable("message.wachis.guide_start"), false);
    }

    /** Llamado al terminar de cavar en el sitio (success=true) o al abandonar. */
    public void stopGuiding(@Nullable LivingEntity owner, boolean success) {
        setGuiding(false);
        setDigging(false);
        BlockPos t = this.treasureTarget;
        this.treasureTarget = null;
        if (success && t != null && this.level() instanceof ServerLevel sl) {
            int y = sl.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, t.getX(), t.getZ());
            this.markerPos = new BlockPos(t.getX(), y, t.getZ());
            this.markerTicks = 1200; // 60 s de columna de luz
            sl.broadcastEntityEvent(this, (byte) 7);
            this.setDeltaMovement(getDeltaMovement().add(0, 0.4, 0));
            this.playSound(SoundEvents.ALLAY_ITEM_GIVEN, 1.0F, 1.0F);
            if (owner instanceof Player p) p.displayClientMessage(Component.translatable("message.wachis.found"), false);
        } else if (owner instanceof Player p) {
            p.displayClientMessage(Component.translatable("message.wachis.guide_stop"), true);
        }
    }

    public void giveUpGuiding(@Nullable LivingEntity owner) {
        setGuiding(false);
        setDigging(false);
        this.treasureTarget = null;
        if (owner instanceof Player p) p.displayClientMessage(Component.translatable("message.wachis.guide_lost"), true);
    }

    // ------------------------------------------------------------ mapas
    private void giveMap(Player player, ItemStack held) {
        if (!(this.level() instanceof ServerLevel sl)) return;
        if (this.mapCooldown > 0) {
            player.displayClientMessage(Component.translatable("message.wachis.map_cooldown"), true);
            this.playSound(SoundEvents.VILLAGER_NO, 0.7F, 1.6F);
            return;
        }
        BlockPos t = TreasureFinder.find(sl, blockPosition(), 100, true);
        if (t == null) t = TreasureFinder.find(sl, blockPosition(), 100, false);
        if (t == null) {
            player.displayClientMessage(Component.translatable("message.wachis.no_treasure"), true);
            this.playSound(SoundEvents.VILLAGER_NO, 0.7F, 1.6F);
            return;
        }
        if (!player.getAbilities().instabuild) held.shrink(1);
        ItemStack map = TreasureFinder.createMap(sl, t);
        if (!player.getInventory().add(map)) player.drop(map, false);
        this.mapCooldown = 6000; // 5 min
        sl.broadcastEntityEvent(this, (byte) 7);
        this.playSound(SoundEvents.ALLAY_ITEM_GIVEN, 1.0F, 1.2F);
        player.displayClientMessage(Component.translatable("message.wachis.map_given"), true);
    }

    // ------------------------------------------------------------ interaccion
    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        ItemStack stack = player.getItemInHand(hand);
        boolean client = this.level().isClientSide;

        if (!isTame()) {
            if (isTreat(stack)) {
                if (!client) {
                    if (!player.getAbilities().instabuild) stack.shrink(1);
                    if (this.random.nextInt(3) == 0) {
                        tame(player);
                        getNavigation().stop();
                        setTarget(null);
                        setOrderedToSit(false);
                        this.level().broadcastEntityEvent(this, (byte) 7);
                        player.displayClientMessage(Component.translatable("message.wachis.tamed"), true);
                    } else {
                        this.level().broadcastEntityEvent(this, (byte) 6);
                    }
                }
                return InteractionResult.sidedSuccess(client);
            }
            return InteractionResult.PASS;
        }

        if (!isOwnedBy(player)) return InteractionResult.PASS;

        if (stack.is(Items.MAP)) {
            if (!client) giveMap(player, stack);
            return InteractionResult.sidedSuccess(client);
        }
        if (isTreat(stack)) {
            if (!client) {
                if (!player.getAbilities().instabuild) stack.shrink(1);
                heal(4.0F);
                this.level().broadcastEntityEvent(this, (byte) 7);
            }
            return InteractionResult.sidedSuccess(client);
        }
        if (stack.isEmpty()) {
            if (!client) {
                if (player.isShiftKeyDown()) {
                    toggleGuiding(player);
                } else {
                    setOrderedToSit(!isOrderedToSit());
                    this.jumping = false;
                    getNavigation().stop();
                    setTarget(null);
                    player.displayClientMessage(Component.translatable(
                            isOrderedToSit() ? "message.wachis.sit" : "message.wachis.stand"), true);
                }
            }
            return InteractionResult.sidedSuccess(client);
        }
        return InteractionResult.PASS;
    }

    // ------------------------------------------------------------ sonidos
    @Nullable
    @Override
    protected SoundEvent getAmbientSound() { return SoundEvents.ALLAY_AMBIENT_WITHOUT_ITEM; }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.ALLAY_HURT; }

    @Override
    protected SoundEvent getDeathSound() { return SoundEvents.ALLAY_DEATH; }
}
