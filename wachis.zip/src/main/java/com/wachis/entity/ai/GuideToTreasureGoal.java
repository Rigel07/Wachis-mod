package com.wachis.entity.ai;

import com.wachis.entity.WachiEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/**
 * El Wachi amigo te guia hasta el tesoro enterrado mas cercano: camina hacia el,
 * te espera si te quedas atras, y al llegar cava y marca el sitio con una columna de luz.
 */
public class GuideToTreasureGoal extends Goal {
    private final WachiEntity wachi;
    private int recalc;
    private int digTicks;
    private int guideTicks;
    private boolean arrived;

    public GuideToTreasureGoal(WachiEntity wachi) {
        this.wachi = wachi;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK, Flag.JUMP));
    }

    @Override
    public boolean canUse() {
        return wachi.isGuiding() && wachi.getTreasureTarget() != null
                && wachi.getOwner() != null && !wachi.isTripped();
    }

    @Override
    public boolean canContinueToUse() {
        return canUse();
    }

    @Override
    public void start() {
        recalc = 0;
        digTicks = 0;
        guideTicks = 0;
        arrived = false;
    }

    @Override
    public void tick() {
        LivingEntity owner = wachi.getOwner();
        BlockPos t = wachi.getTreasureTarget();
        if (owner == null || t == null) return;

        guideTicks++;
        double dx = t.getX() + 0.5 - wachi.getX();
        double dz = t.getZ() + 0.5 - wachi.getZ();
        double distT = Math.sqrt(dx * dx + dz * dz);
        double distO = wachi.distanceTo(owner);

        if (distO > 45 || guideTicks > 7200) {
            wachi.giveUpGuiding(owner);
            return;
        }

        if (arrived) {
            digTicks--;
            wachi.getNavigation().stop();
            wachi.setDigging(true);
            if (digTicks % 8 == 0) wachi.digEffects();
            if (digTicks <= 0) wachi.stopGuiding(owner, true);
            return;
        }

        if (distT < 5.0D) {
            arrived = true;
            digTicks = 90;
            wachi.getNavigation().stop();
            return;
        }

        if (distO > 10) { // espera al jugador
            wachi.getNavigation().stop();
            wachi.getLookControl().setLookAt(owner, 30.0F, 30.0F);
            return;
        }

        if (--recalc <= 0) {
            recalc = 20;
            Vec3 target = new Vec3(t.getX() + 0.5, wachi.getY(), t.getZ() + 0.5);
            Vec3 leg = DefaultRandomPos.getPosTowards(wachi, 14, 6, target, Math.PI / 2.5D);
            if (leg == null) {
                leg = new Vec3(wachi.getX() + dx / distT * 8, wachi.getY(), wachi.getZ() + dz / distT * 8);
            }
            wachi.getNavigation().moveTo(leg.x, leg.y, leg.z, 1.0D);
        }
    }

    @Override
    public void stop() {
        wachi.setDigging(false);
    }
}
