package com.wachis.entity.ai;

import com.wachis.entity.WachiEntity;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.util.EnumSet;

/** El Wachi se para a cavar un hoyo buscando tesoros (a veces encuentra algo, a veces nada). */
public class DigForTreasureGoal extends Goal {
    private final WachiEntity wachi;
    private int ticks;

    public DigForTreasureGoal(WachiEntity wachi) {
        this.wachi = wachi;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK, Flag.JUMP));
    }

    @Override
    public boolean canUse() {
        if (wachi.isTripped() || wachi.isInSittingPose() || wachi.isGuiding() || !wachi.onGround()) return false;
        if (wachi.getRandom().nextInt(wachi.isTame() ? 700 : 450) != 0) return false;
        if (wachi.isTame()) {
            LivingEntity owner = wachi.getOwner();
            if (owner == null || wachi.distanceToSqr(owner) > 12 * 12) return false;
        }
        BlockState below = wachi.level().getBlockState(wachi.blockPosition().below());
        return below.is(BlockTags.DIRT) || below.is(BlockTags.SAND) || below.is(Blocks.GRAVEL);
    }

    @Override
    public boolean canContinueToUse() {
        return ticks > 0 && !wachi.isTripped() && !wachi.isInSittingPose();
    }

    @Override
    public void start() {
        ticks = 70;
        wachi.setDigging(true);
        wachi.getNavigation().stop();
    }

    @Override
    public void tick() {
        ticks--;
        if (ticks % 8 == 0) wachi.digEffects();
    }

    @Override
    public void stop() {
        wachi.setDigging(false);
        if (ticks <= 0) wachi.finishDig();
    }
}
