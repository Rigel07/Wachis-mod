package com.wachis.item;

import com.wachis.WachisMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, WachisMod.MOD_ID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup." + WachisMod.MOD_ID))
                    .icon(() -> new ItemStack(ModItems.WACHI_COIN.get()))
                    .displayItems((params, output) -> {
                        output.accept(ModItems.WACHI_SPAWN_EGG.get());
                        output.accept(ModItems.WACHI_COIN.get());
                    })
                    .build());
}
