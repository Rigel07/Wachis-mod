package com.wachis.item;

import com.wachis.WachisMod;
import com.wachis.entity.ModEntities;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, WachisMod.MOD_ID);

    /** Moneda Wachi: botin de tesoros. A los Wachis les encanta. */
    public static final RegistryObject<Item> WACHI_COIN = ITEMS.register("wachi_coin",
            () -> new Item(new Item.Properties().rarity(Rarity.UNCOMMON)));

    public static final RegistryObject<Item> WACHI_SPAWN_EGG = ITEMS.register("wachi_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.WACHI, 0xF3E2B8, 0xC0392B, new Item.Properties()));
}
